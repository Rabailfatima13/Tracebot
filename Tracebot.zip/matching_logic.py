"""
Simple matching algorithm to compare lost and found items
Uses basic string comparison and simple logic
"""

def convert_to_lowercase(text):
    """Convert text to lowercase for comparison"""
    return text.lower()

def check_keyword_match(text1, text2):
    """
    Check if keywords from text1 are in text2
    Returns match score (0-100)
    """
    text1_lower = convert_to_lowercase(text1)
    text2_lower = convert_to_lowercase(text2)
    
    # Split text into words
    words1 = text1_lower.split()
    words2 = text2_lower.split()
    
    # Count matching words
    matching_words = 0
    for word in words1:
        if word in text2_lower:
            matching_words = matching_words + 1
    
    # Calculate percentage
    if len(words1) == 0:
        return 0
    
    score = (matching_words / len(words1)) * 100
    return score

def check_category_match(category1, category2):
    """
    Check if categories match exactly
    Returns 100 if match, 0 if no match
    """
    cat1_lower = convert_to_lowercase(category1)
    cat2_lower = convert_to_lowercase(category2)
    
    if cat1_lower == cat2_lower:
        return 100
    else:
        return 0

def check_location_similarity(location1, location2):
    """
    Check if locations are similar
    Returns higher score if locations contain common words
    """
    location1_lower = convert_to_lowercase(location1)
    location2_lower = convert_to_lowercase(location2)
    
    words1 = location1_lower.split()
    words2 = location2_lower.split()
    
    matching_location_words = 0
    for word in words1:
        if word in location2_lower:
            matching_location_words = matching_location_words + 1
    
    if len(words1) == 0:
        return 0
    
    score = (matching_location_words / len(words1)) * 100
    return score

def calculate_match_score(lost_item, found_item):
    """
    Calculate how well a lost and found item match
    Uses weighted scoring:
    - Item name: 40%
    - Category: 25%
    - Description: 20%
    - Location: 15%
    Returns score from 0-100
    """
    
    # Get item name match score (40% weight)
    name_score = check_keyword_match(lost_item['item_name'], found_item['item_name'])
    name_weighted = (name_score / 100) * 40
    
    # Get category match score (25% weight)
    category_score = check_category_match(lost_item['category'], found_item['category'])
    category_weighted = (category_score / 100) * 25
    
    # Get description match score (20% weight)
    description_score = check_keyword_match(lost_item['description'], found_item['description'])
    description_weighted = (description_score / 100) * 20
    
    # Get location match score (15% weight)
    location_score = check_location_similarity(lost_item['location'], found_item['location'])
    location_weighted = (location_score / 100) * 15
    
    # Total score
    total_score = name_weighted + category_weighted + description_weighted + location_weighted
    
    return total_score

def find_matches_for_lost_item(lost_item, found_items):
    """
    Find matching found items for a lost item
    Returns list of matches with scores
    """
    matches = []
    
    # Loop through all found items
    for found_item in found_items:
        # Only check available items
        if found_item['status'] == 'available':
            score = calculate_match_score(lost_item, found_item)
            
            # Only include matches with score > 30
            if score > 30:
                match = {
                    'found_item_id': found_item['id'],
                    'found_item_name': found_item['item_name'],
                    'found_location': found_item['location'],
                    'found_date': found_item['date'],
                    'match_score': score
                }
                matches.append(match)
    
    # Sort matches by score (highest first)
    # Using simple bubble sort (basic algorithm)
    for i in range(len(matches)):
        for j in range(len(matches) - 1 - i):
            if matches[j]['match_score'] < matches[j + 1]['match_score']:
                # Swap
                temp = matches[j]
                matches[j] = matches[j + 1]
                matches[j + 1] = temp
    
    return matches

def find_matches_for_found_item(found_item, lost_items):
    """
    Find matching lost items for a found item
    Returns list of matches with scores
    """
    matches = []
    
    # Loop through all lost items
    for lost_item in lost_items:
        # Only check lost items that are still lost
        if lost_item['status'] == 'lost':
            score = calculate_match_score(lost_item, found_item)
            
            # Only include matches with score > 30
            if score > 30:
                match = {
                    'lost_item_id': lost_item['id'],
                    'lost_item_name': lost_item['item_name'],
                    'lost_location': lost_item['location'],
                    'lost_date': lost_item['date'],
                    'reporter_username': lost_item['username'],
                    'match_score': score
                }
                matches.append(match)
    
    # Sort matches by score (highest first)
    for i in range(len(matches)):
        for j in range(len(matches) - 1 - i):
            if matches[j]['match_score'] < matches[j + 1]['match_score']:
                temp = matches[j]
                matches[j] = matches[j + 1]
                matches[j + 1] = temp
    
    return matches