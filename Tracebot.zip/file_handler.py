import os
from config import USERS_FILE, LOST_ITEMS_FILE, FOUND_ITEMS_FILE, USER_SEPARATOR, ITEM_SEPARATOR

# ==================== USER FILE OPERATIONS ====================

def read_users():
    """Read all users from file and return as list of dictionaries"""
    users = []
    
    if os.path.exists(USERS_FILE):
        try:
            file = open(USERS_FILE, 'r')
            for line in file:
                line = line.strip()
                if line:  # Skip empty lines
                    # Parse user data: username|email|password|full_name|phone
                    parts = line.split(USER_SEPARATOR)
                    if len(parts) == 5:
                        user = {
                            'username': parts[0],
                            'email': parts[1],
                            'password': parts[2],
                            'full_name': parts[3],
                            'phone': parts[4]
                        }
                        users.append(user)
            file.close()
        except Exception as e:
            print(f"Error reading users file: {e}")
    
    return users

def write_user(username, email, password, full_name, phone):
    """Write a new user to file"""
    try:
        file = open(USERS_FILE, 'a')
        user_data = f"{username}{USER_SEPARATOR}{email}{USER_SEPARATOR}{password}{USER_SEPARATOR}{full_name}{USER_SEPARATOR}{phone}\n"
        file.write(user_data)
        file.close()
        return True
    except Exception as e:
        print(f"Error writing user: {e}")
        return False

def user_exists(username):
    """Check if user already exists"""
    users = read_users()
    for user in users:
        if user['username'] == username:
            return True
    return False

def verify_user(username, password):
    """Verify user login credentials"""
    users = read_users()
    for user in users:
        if user['username'] == username and user['password'] == password:
            return True
    return False

def get_user(username):
    """Get user details by username"""
    users = read_users()
    for user in users:
        if user['username'] == username:
            return user
    return None

# ==================== LOST ITEMS FILE OPERATIONS ====================

def read_lost_items():
    """Read all lost items from file and return as list of dictionaries"""
    items = []
    
    if os.path.exists(LOST_ITEMS_FILE):
        try:
            file = open(LOST_ITEMS_FILE, 'r')
            for line in file:
                line = line.strip()
                if line:
                    # Parse item data: id|username|item_name|description|location|date|category|status|image
                    parts = line.split(ITEM_SEPARATOR)
                    if len(parts) == 9:
                        item = {
                            'id': parts[0],
                            'username': parts[1],
                            'item_name': parts[2],
                            'description': parts[3],
                            'location': parts[4],
                            'date': parts[5],
                            'category': parts[6],
                            'status': parts[7],
                            'image': parts[8]
                        }
                        items.append(item)
            file.close()
        except Exception as e:
            print(f"Error reading lost items file: {e}")
    
    return items

def write_lost_item(item_id, username, item_name, description, location, date, category, image):
    """Write a new lost item to file"""
    try:
        file = open(LOST_ITEMS_FILE, 'a')
        item_data = f"{item_id}{ITEM_SEPARATOR}{username}{ITEM_SEPARATOR}{item_name}{ITEM_SEPARATOR}{description}{ITEM_SEPARATOR}{location}{ITEM_SEPARATOR}{date}{ITEM_SEPARATOR}{category}{ITEM_SEPARATOR}lost{ITEM_SEPARATOR}{image}\n"
        file.write(item_data)
        file.close()
        return True
    except Exception as e:
        print(f"Error writing lost item: {e}")
        return False

def get_next_lost_item_id():
    """Get next ID for lost item"""
    items = read_lost_items()
    if len(items) == 0:
        return "L001"
    
    last_id = items[len(items) - 1]['id']
    # Extract number from last ID
    number = int(last_id[1:])
    next_number = number + 1
    return f"L{str(next_number).zfill(3)}"

# ==================== FOUND ITEMS FILE OPERATIONS ====================

def read_found_items():
    """Read all found items from file and return as list of dictionaries"""
    items = []
    
    if os.path.exists(FOUND_ITEMS_FILE):
        try:
            file = open(FOUND_ITEMS_FILE, 'r')
            for line in file:
                line = line.strip()
                if line:
                    # Parse item data: id|username|item_name|description|location|date|category|status|image
                    parts = line.split(ITEM_SEPARATOR)
                    if len(parts) == 9:
                        item = {
                            'id': parts[0],
                            'username': parts[1],
                            'item_name': parts[2],
                            'description': parts[3],
                            'location': parts[4],
                            'date': parts[5],
                            'category': parts[6],
                            'status': parts[7],
                            'image': parts[8]
                        }
                        items.append(item)
            file.close()
        except Exception as e:
            print(f"Error reading found items file: {e}")
    
    return items

def write_found_item(item_id, username, item_name, description, location, date, category, image):
    """Write a new found item to file"""
    try:
        file = open(FOUND_ITEMS_FILE, 'a')
        item_data = f"{item_id}{ITEM_SEPARATOR}{username}{ITEM_SEPARATOR}{item_name}{ITEM_SEPARATOR}{description}{ITEM_SEPARATOR}{location}{ITEM_SEPARATOR}{date}{ITEM_SEPARATOR}{category}{ITEM_SEPARATOR}available{ITEM_SEPARATOR}{image}\n"
        file.write(item_data)
        file.close()
        return True
    except Exception as e:
        print(f"Error writing found item: {e}")
        return False

def get_next_found_item_id():
    """Get next ID for found item"""
    items = read_found_items()
    if len(items) == 0:
        return "F001"
    
    last_id = items[len(items) - 1]['id']
    number = int(last_id[1:])
    next_number = number + 1
    return f"F{str(next_number).zfill(3)}"

def update_found_item_status(item_id, new_status):
    """Update status of a found item (claimed/disposed)"""
    items = read_found_items()
    
    try:
        file = open(FOUND_ITEMS_FILE, 'w')
        for item in items:
            if item['id'] == item_id:
                item['status'] = new_status
            item_data = f"{item['id']}{ITEM_SEPARATOR}{item['username']}{ITEM_SEPARATOR}{item['item_name']}{ITEM_SEPARATOR}{item['description']}{ITEM_SEPARATOR}{item['location']}{ITEM_SEPARATOR}{item['date']}{ITEM_SEPARATOR}{item['category']}{ITEM_SEPARATOR}{item['status']}{ITEM_SEPARATOR}{item['image']}\n"
            file.write(item_data)
        file.close()
        return True
    except Exception as e:
        print(f"Error updating found item: {e}")
        return False

def update_lost_item_status(item_id, new_status):
    """Update status of a lost item (found/claimed)"""
    items = read_lost_items()
    
    try:
        file = open(LOST_ITEMS_FILE, 'w')
        for item in items:
            if item['id'] == item_id:
                item['status'] = new_status
            item_data = f"{item['id']}{ITEM_SEPARATOR}{item['username']}{ITEM_SEPARATOR}{item['item_name']}{ITEM_SEPARATOR}{item['description']}{ITEM_SEPARATOR}{item['location']}{ITEM_SEPARATOR}{item['date']}{ITEM_SEPARATOR}{item['category']}{ITEM_SEPARATOR}{item['status']}{ITEM_SEPARATOR}{item['image']}\n"
            file.write(item_data)
        file.close()
        return True
    except Exception as e:
        print(f"Error updating lost item: {e}")
        return False