from flask import Flask, request, jsonify, session, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
from datetime import datetime
import os
from config import UPLOADS_FOLDER, ALLOWED_EXTENSIONS
from file_handler import (
    read_users, write_user, user_exists, verify_user, get_user,
    read_lost_items, write_lost_item, get_next_lost_item_id, update_lost_item_status,
    read_found_items, write_found_item, get_next_found_item_id, update_found_item_status
)
from matching_logic import find_matches_for_lost_item, find_matches_for_found_item

app = Flask(__name__, static_folder='.', static_url_path='')
app.secret_key = 'tracebot-secret-key'

# Enable CORS - Allow requests from browser
CORS(app, supports_credentials=True, origins=['*'], allow_headers=['*'])

# Create uploads folder if doesn't exist
os.makedirs(UPLOADS_FOLDER, exist_ok=True)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

# Admin account credentials
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin123'
ADMIN_EMAIL = 'admin@tracebot.com'
ADMIN_NAME = 'Admin Staff'

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_image(file):
    """Save uploaded image and return filename"""
    if file and file.filename != '':
        if allowed_file(file.filename):
            filename = secure_filename(file.filename)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_')
            filename = timestamp + filename
            filepath = os.path.join(UPLOADS_FOLDER, filename)
            file.save(filepath)
            return filename
    return None

# ==================== SERVE HTML FILES ====================

@app.route('/', defaults={'path': 'home.html'})
@app.route('/<path:path>')
def serve_static(path):
    """Serve static files (HTML, CSS, JS, images)"""
    if path != '' and os.path.exists(path):
        return send_from_directory('.', path)
    return send_from_directory('.', 'home.html')

# ==================== HEALTH CHECK ====================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Check if backend is running"""
    return jsonify({'status': 'ok', 'message': 'TraceBot backend is running'}), 200

# ==================== AUTHENTICATION ROUTES ====================

@app.route('/api/auth/signup', methods=['POST'])
def signup():
    """Register a new user"""
    try:
        data = request.get_json()
        
        full_name = data.get('full_name', '')
        username = data.get('username', '')
        email = data.get('email', '')
        password = data.get('password', '')
        phone = data.get('contact_phone', '')
        
        if not full_name or not username or not email or not password:
            return jsonify({'error': 'Missing required fields'}), 400
        
        if user_exists(username):
            return jsonify({'error': 'Username already exists'}), 409
        
        if write_user(username, email, password, full_name, phone):
            return jsonify({
                'message': 'Account created successfully',
                'user': {
                    'username': username,
                    'email': email,
                    'full_name': full_name
                }
            }), 201
        else:
            return jsonify({'error': 'Error creating account'}), 500
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/auth/login', methods=['POST'])
def login():
    """Login user or admin"""
    try:
        data = request.get_json()
        
        username = data.get('username', '')
        password = data.get('password', '')
        
        if not username or not password:
            return jsonify({'error': 'Username and password required'}), 400
        
        # Check if admin login
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['username'] = ADMIN_USERNAME
            session['is_admin'] = True
            return jsonify({
                'message': 'Admin login successful',
                'user': {
                    'username': ADMIN_USERNAME,
                    'email': ADMIN_EMAIL,
                    'full_name': ADMIN_NAME,
                    'is_admin': True
                }
            }), 200
        
        # Check regular user login
        if verify_user(username, password):
            session['username'] = username
            session['is_admin'] = False
            user_data = get_user(username)
            
            return jsonify({
                'message': 'Login successful',
                'user': {
                    'username': user_data['username'],
                    'email': user_data['email'],
                    'full_name': user_data['full_name'],
                    'is_admin': False
                }
            }), 200
        else:
            return jsonify({'error': 'Invalid username or password'}), 401
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    """Logout user"""
    session.clear()
    return jsonify({'message': 'Logged out successfully'}), 200

@app.route('/api/auth/user', methods=['GET'])
def get_current_user():
    """Get current logged-in user"""
    username = session.get('username')
    
    if not username:
        return jsonify({'error': 'Not logged in'}), 401
    
    if username == ADMIN_USERNAME:
        return jsonify({
            'username': ADMIN_USERNAME,
            'email': ADMIN_EMAIL,
            'full_name': ADMIN_NAME,
            'is_admin': True
        }), 200
    
    user_data = get_user(username)
    if user_data:
        return jsonify({
            'username': user_data['username'],
            'email': user_data['email'],
            'full_name': user_data['full_name'],
            'is_admin': False
        }), 200
    else:
        return jsonify({'error': 'User not found'}), 404

# ==================== LOST ITEMS ROUTES ====================

@app.route('/api/items/lost', methods=['POST'])
def report_lost_item():
    """Report a lost item"""
    try:
        username = session.get('username')
        if not username:
            return jsonify({'error': 'Not logged in'}), 401
        
        item_name = request.form.get('item_name', '')
        description = request.form.get('description', '')
        location = request.form.get('location', '')
        date = request.form.get('date', datetime.now().strftime('%Y-%m-%d'))
        category = request.form.get('category', 'Other')
        
        if not item_name or not location:
            return jsonify({'error': 'Item name and location are required'}), 400
        
        image_filename = ''
        if 'image' in request.files:
            image_filename = save_image(request.files['image'])
            if image_filename is None:
                image_filename = ''
        
        item_id = get_next_lost_item_id()
        
        if write_lost_item(item_id, username, item_name, description, location, date, category, image_filename):
            return jsonify({
                'message': 'Lost item reported successfully',
                'item_id': item_id,
                'item': {
                    'id': item_id,
                    'item_name': item_name,
                    'location': location,
                    'date': date,
                    'category': category
                }
            }), 201
        else:
            return jsonify({'error': 'Error reporting lost item'}), 500
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/items/lost', methods=['GET'])
def get_lost_items():
    """Get all lost items"""
    try:
        items = read_lost_items()
        return jsonify({
            'items': items,
            'total': len(items)
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/items/lost/<item_id>', methods=['GET'])
def get_lost_item(item_id):
    """Get specific lost item"""
    try:
        items = read_lost_items()
        
        for item in items:
            if item['id'] == item_id:
                return jsonify(item), 200
        
        return jsonify({'error': 'Item not found'}), 404
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ==================== FOUND ITEMS ROUTES ====================

@app.route('/api/items/found', methods=['POST'])
def report_found_item():
    """Report a found item"""
    try:
        username = session.get('username')
        if not username:
            return jsonify({'error': 'Not logged in'}), 401
        
        item_name = request.form.get('item_name', '')
        description = request.form.get('description', '')
        location = request.form.get('location', '')
        date = request.form.get('date', datetime.now().strftime('%Y-%m-%d'))
        category = request.form.get('category', 'Other')
        
        if not item_name or not location:
            return jsonify({'error': 'Item name and location are required'}), 400
        
        image_filename = ''
        if 'image' in request.files:
            image_filename = save_image(request.files['image'])
            if image_filename is None:
                image_filename = ''
        
        item_id = get_next_found_item_id()
        
        if write_found_item(item_id, username, item_name, description, location, date, category, image_filename):
            return jsonify({
                'message': 'Found item reported successfully',
                'item_id': item_id,
                'item': {
                    'id': item_id,
                    'item_name': item_name,
                    'location': location,
                    'date': date,
                    'category': category
                }
            }), 201
        else:
            return jsonify({'error': 'Error reporting found item'}), 500
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/items/found', methods=['GET'])
def get_found_items():
    """Get all found items"""
    try:
        items = read_found_items()
        return jsonify({
            'items': items,
            'total': len(items)
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/items/found/<item_id>', methods=['GET'])
def get_found_item(item_id):
    """Get specific found item"""
    try:
        items = read_found_items()
        
        for item in items:
            if item['id'] == item_id:
                return jsonify(item), 200
        
        return jsonify({'error': 'Item not found'}), 404
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/items/found/<item_id>/claim', methods=['POST'])
def claim_found_item(item_id):
    """Claim a found item"""
    try:
        username = session.get('username')
        if not username:
            return jsonify({'error': 'Not logged in'}), 401
        
        if update_found_item_status(item_id, 'claimed'):
            return jsonify({'message': 'Item claimed successfully'}), 200
        else:
            return jsonify({'error': 'Error claiming item'}), 500
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ==================== ADMIN DASHBOARD ROUTES ====================

@app.route('/api/admin/dashboard', methods=['GET'])
def admin_dashboard():
    """Get admin dashboard with all items and stats"""
    try:
        is_admin = session.get('is_admin', False)
        
        if not is_admin:
            return jsonify({'error': 'Access denied. Admin only'}), 403
        
        lost_items = read_lost_items()
        found_items = read_found_items()
        users = read_users()
        
        # Calculate statistics
        total_lost = len(lost_items)
        total_found = len(found_items)
        claimed_items = len([item for item in found_items if item['status'] == 'claimed'])
        available_items = len([item for item in found_items if item['status'] == 'available'])
        
        return jsonify({
            'status': 'success',
            'is_admin': True,
            'stats': {
                'total_users': len(users),
                'total_lost_items': total_lost,
                'total_found_items': total_found,
                'claimed_items': claimed_items,
                'available_items': available_items
            },
            'lost_items': lost_items,
            'found_items': found_items,
            'users': [
                {
                    'username': user['username'],
                    'email': user['email'],
                    'full_name': user['full_name'],
                    'phone': user['phone']
                } for user in users
            ]
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/all-items', methods=['GET'])
def admin_all_items():
    """Get all items (lost and found) for admin view"""
    try:
        is_admin = session.get('is_admin', False)
        
        if not is_admin:
            return jsonify({'error': 'Access denied. Admin only'}), 403
        
        lost_items = read_lost_items()
        found_items = read_found_items()
        
        return jsonify({
            'lost_items': lost_items,
            'found_items': found_items,
            'total_items': len(lost_items) + len(found_items)
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ==================== SEARCH & MATCHING ROUTES ====================

@app.route('/api/search/lost-item/<lost_item_id>', methods=['GET'])
def find_lost_item_matches(lost_item_id):
    """Find matches for a lost item"""
    try:
        lost_items = read_lost_items()
        found_items = read_found_items()
        
        lost_item = None
        for item in lost_items:
            if item['id'] == lost_item_id:
                lost_item = item
                break
        
        if not lost_item:
            return jsonify({'error': 'Lost item not found'}), 404
        
        matches = find_matches_for_lost_item(lost_item, found_items)
        
        return jsonify({
            'lost_item': lost_item,
            'matches': matches,
            'total_matches': len(matches)
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/search/found-item/<found_item_id>', methods=['GET'])
def find_found_item_matches(found_item_id):
    """Find matches for a found item"""
    try:
        lost_items = read_lost_items()
        found_items = read_found_items()
        
        found_item = None
        for item in found_items:
            if item['id'] == found_item_id:
                found_item = item
                break
        
        if not found_item:
            return jsonify({'error': 'Found item not found'}), 404
        
        matches = find_matches_for_found_item(found_item, lost_items)
        
        return jsonify({
            'found_item': found_item,
            'matches': matches,
            'total_matches': len(matches)
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/search/items', methods=['GET'])
def search_items():
    """Search for items by name or category"""
    try:
        query = request.args.get('q', '').lower()
        item_type = request.args.get('type', 'both')
        
        results = {'lost_items': [], 'found_items': []}
        
        if item_type in ['lost', 'both']:
            lost_items = read_lost_items()
            for item in lost_items:
                item_name_lower = item['item_name'].lower()
                location_lower = item['location'].lower()
                if query in item_name_lower or query in location_lower:
                    results['lost_items'].append(item)
        
        if item_type in ['found', 'both']:
            found_items = read_found_items()
            for item in found_items:
                item_name_lower = item['item_name'].lower()
                location_lower = item['location'].lower()
                if query in item_name_lower or query in location_lower:
                    results['found_items'].append(item)
        
        return jsonify(results), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ==================== IMAGE SERVING ====================

@app.route('/uploads/<filename>', methods=['GET'])
def serve_image(filename):
    """Serve uploaded images"""
    try:
        return send_from_directory(UPLOADS_FOLDER, filename)
    except Exception as e:
        return jsonify({'error': 'File not found'}), 404

# ==================== ERROR HANDLERS ====================

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Resource not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    app.run(debug=True, host='localhost', port=5000)