import os

# File paths for data storage
DATA_FOLDER = 'data'
USERS_FILE = os.path.join(DATA_FOLDER, 'users.txt')
LOST_ITEMS_FILE = os.path.join(DATA_FOLDER, 'lost_items.txt')
FOUND_ITEMS_FILE = os.path.join(DATA_FOLDER, 'found_items.txt')
UPLOADS_FOLDER = 'uploads'

# Create data folder if doesn't exist
os.makedirs(DATA_FOLDER, exist_ok=True)
os.makedirs(UPLOADS_FOLDER, exist_ok=True)

# Flask settings
SECRET_KEY = 'tracebot-secret-key'
DEBUG = True
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size

# Allowed file extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

# Data format constants
USER_SEPARATOR = '|'  # Separator for user fields
ITEM_SEPARATOR = '|'  # Separator for item fields
FIELD_SEPARATOR = '||'  # Separator between records